package prjPokemonV2;



public class PokemonAgua extends Pokemon {
		//Construtores da subclasse
		
		public void PokemonAgua() {
			
		}
		
		public PokemonAgua(String nome, String tipo, int nivel, int hp, int defesa) {
			setNome(nome);
			setTipo(tipo);
			setNivel(nivel);
			setHp(hp);
			setDefesa(defesa);
			
		}
		//Metodos da Subclasse
		@ Override
		public void atacar() {
			System.out.println(this.getNome() + " usou surf!");
		}
		
		public void ataqueAgua() {
			System.out.println(this.getNome() + " usou canhão de água!");
		}
		
		
	}

