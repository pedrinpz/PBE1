package prjPokemonV2;



public class PokemonFogo extends Pokemon {
		//Construtores da subclasse
		
		public PokemonFogo() {
			
		}
		
		public PokemonFogo(String nome, String tipo, int nivel, int hp, int defesa) {
			setNome(nome);
			setTipo(tipo);
			setNivel(nivel);
			setHp(hp);
			setDefesa(defesa);
			
		}
		//Metodos da Subclasse
		@ Override
		public void atacar() {
			System.out.println(this.getNome() + " atacou com bola de fogo!");
		}
		
		public void bolaFogo() {
			System.out.println(this.getNome() + " usou explosão de fogo!");
		}
		public void lancaFogo() {
			System.out.println(this.getNome() + " usou Lança chamas!");
		}
		
	}


