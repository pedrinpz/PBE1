package prjPokemonV2;

public class aplicacao {

	public static void main(String[] args) {
			Pokemon charmander = new PokemonFogo();
			charmander.nome = "charmander";
			charmander.tipo = "Fogo";
			charmander.nivel = 15;
			charmander.hp = 100;
			
			Pokemon charizard = new PokemonFogo();
			charizard.nome = "charizard";
			charizard.tipo = "Fogo";
			charizard.nivel = 25;
			charizard.hp = 99;
			
			Pokemon squirtle = new PokemonAgua();
			squirtle.nome = "Squirtle";
			squirtle.tipo = "Água";
			squirtle.nivel = 14;
			squirtle.hp = 79;
			
			Pokemon aguinha = new PokemonAgua();
			aguinha.nome = "Aguinha";
			aguinha.tipo = "Água";
			aguinha.nivel = 16;
			aguinha.hp = 81;
			
			Pokemon pidgey = new PokemonVoador();
			pidgey.nome = "Pidgey";
			pidgey.tipo = "Voador";
			pidgey.nivel = 16;
			pidgey.hp = 97;
			
			Pokemon pomba = new PokemonVoador();
			pomba.nome = "Pomba";
			pomba.tipo = "Voador";
			pomba.nivel = 16;
			pomba.hp = 97;
		
			//Exibir as informações
			
			pomba.atacar();
			pomba.exibirInfo();
			pomba.evoluir();
			pomba.exibirInfo();
			
			pidgey.atacar();
			pidgey.exibirInfo();
			pidgey.evoluir();
			pidgey.exibirInfo();
			
			pidgey.atacar();
			pidgey.exibirInfo();
			pidgey.evoluir();
			pidgey.exibirInfo();
			
			
		}

	

	}


