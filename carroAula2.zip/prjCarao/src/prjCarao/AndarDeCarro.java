package prjCarao;

import java.util.Scanner;

public class AndarDeCarro {

	public static void main(String[] args) {
		Scanner sc = new Scanner (System.in);
		
		System.out.println("Qual é a marca do Carro? ");
		String marca = sc .next();
		System.out.println("Qual é a modelo do Carro? ");
		String modelo = sc .next();
		System.out.println("Qual é a velocidade do Carro em Km/h? ");
		int velocidade = sc .nextInt();
		
		System.out.println("Quer acelerar ou desacelerar? \n 1) Acelerar\n 2 Desacelerar");
		int opcao = sc.nextInt();
		
		if(opcao == 1) {
		   System.out.println("Quanto irá acelerar? ");
		   int aceleracao = sc.nextInt();
		   velocidade += aceleracao;
		}
		else if(opcao == 2) {
			System.out.println("Quanto irá desacelerar? ");
			int desaceleracao = sc.nextInt();
			velocidade -= desaceleracao;
		}
		else {
			System.out.print("Você se manteve na mesma velocidade \n");
		}
		System.out.print("A marca do carro:"+ marca + "\n");
		System.out.print("A modelo do carro:"+ modelo + "\n");
		System.out.print("A velocidade atual do carro:"+ velocidade + "Km/h");
			
			
		}

	}


