package prjExercicio01;

import java.util.Scanner;

public class Aplicacao {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Carro carro01 = new Carro();
		carro01.modelo = "Golf";
		carro01.marca = "Volkswagen";
		carro01.placa = "824100";
		carro01.ano = 2022;
		
		Carro carro02 = new Carro();
		carro02.modelo = "Mustang";
		carro02.marca = "Ford";
		carro02.placa = "240308";
		carro02.ano = 2025;
		
		carro01.exibirInfo();
		
		carro02.exibirInfo();		
	}

}
