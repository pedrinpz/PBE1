package prjExercicio01;

public class Carro {
	
	// Atributos
	
		String marca;
		String modelo;
		String placa;
		int ano;
		
		// Contrutores
		public Carro() {
			
		}
		
		public Carro (String marca, String modelo, String placa, int ano) {
		  this. marca = marca;
		  this. modelo = modelo;
		  this. placa = placa;
		  this.ano = ano;
		}
		
		//Metodos
		public void exibirInfo() {
			System.out.println("A marca do carro é: " + this.marca);
			System.out.println("O modelo do carro é: " + this.modelo);
			System.out.println("A placa do carro é: " + this.placa);
			System.out.println("O ano do carro é: " + this.ano);
		}
	}



