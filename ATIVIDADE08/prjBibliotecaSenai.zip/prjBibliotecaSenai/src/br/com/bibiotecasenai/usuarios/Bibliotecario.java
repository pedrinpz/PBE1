package br.com.bibiotecasenai.usuarios;

public class Bibliotecario extends Pessoa{
	
	//atributos
	private String matricula;
	
	//getters e setters
	public String getMatricula() {
		return matricula;
	}
	public void setMatricula(String matricula) {
		this.matricula = matricula;
	}
	
	//metodos
	public void realizarEmprestimo() {
		System.out.println (this.getNome() + " emprestou um livro.");
	}
	public void devolverLivro () {
		System.out.println(this.getNome() + " devolveu o livro.");
	}

}