package br.com.bibiotecasenai.usuarios;

import br.com.bibiotecasenai.usuarios.Bibliotecario;
import br.com.bibiotecasenai.usuarios.Usuario;

public class Pessoa {
	
	//atributos
	private String nome;
	private int idade;
	
	//construtores
	public Pessoa() {
	}
	public Pessoa(String nome) {
		this.nome = nome;
		this.idade = 0;
	}
	
	//getters e setters
	public void setNome (String nome ) {
		this.nome = nome;
	}
	public String getNome() {
		return nome;
	}
	public void setIdade (int idade) {
		this.idade = idade;
	}
	public int getIdade() {
		return idade;
	}
	}
