package br.com.bibiotecasenai.usuarios;

public class Usuario extends Pessoa{
	
	//atributos
	private int cpf;
	private int livrosEmprestados;
	
	//getters e setters
	
	public int getCpf() {
		return cpf;
	}
	public void setCpf(int cpf) {
		this.cpf = cpf;
	}
	public int getLivrosEmprestados() {
		return livrosEmprestados;
	}
	public void setLivrosEmprestados(int livrosEmprestados) {
		this.livrosEmprestados = livrosEmprestados;
	}	
}


