package br.com.bibiotecasenai.itens;

public class Livro {
	
	//atributos
	private String titulo;
	private String autor;
	private int isbn;
	private boolean disponivel;
	
	//getters e setters
	
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public String getAutor() {
		return autor;
	}
	public void setAutor(String autor) {
		this.autor = autor;
	}
	public int getIsbn() {
		return isbn;
	}
	public void setisbn(int isbn) {
		this.isbn = isbn;
	}
	public boolean getDisponivel() {
		return disponivel;
	}
	public void setDisponivel(boolean disponivel) {
		this.disponivel = disponivel;
	}
}
