package br.com.bibiotecasenai.itens;

import br.com.bibiotecasenai.usuarios.Usuario;

public class Empréstimo {
	
	//atributos
	private int numeroEmprestimo;
	
	//metodos
	public void emprestarlivro(Livro livro, Usuario usuario) {
		usuario.setLivrosEmprestados(usuario.getLivrosEmprestados()+1);
	}
	public void devolverLivro(Livro livro, Usuario usuario) {
		usuario.setLivrosEmprestados(usuario.getLivrosEmprestados()-1);
	}

}
