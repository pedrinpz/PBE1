package br.com.bibiotecasenai.principal;

import br.com.bibiotecasenai.usuarios.Usuario;
import br.com.bibiotecasenai.usuarios.Pessoa;
import br.com.bibiotecasenai.itens.Livro;
import br.com.bibiotecasenai.usuarios.Bibliotecario;
import br.com.bibiotecasenai.itens.Empréstimo;


public class Aplicacao {

	public static void main(String[] args) {
		
		Usuario usuario01 = new Usuario();
		usuario01.setNome("Julia");
		usuario01.setIdade (12);
		usuario01.setCpf(1234599911);
		
		for (int i = 0; i < 10; i++) {
		    usuario01.();	
		}
	}
}
	
	


